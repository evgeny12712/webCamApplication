package Gallery;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

class FilesContent {

    static final List<File> ITEMS = new ArrayList<>();

    public static void loadSavedFiles(File dir) {
        ITEMS.clear();
        if(dir.exists()) {
            File[] files = dir.listFiles();
            for (File file : files) {
                ITEMS.add(file);
            }
        }
    }
}
