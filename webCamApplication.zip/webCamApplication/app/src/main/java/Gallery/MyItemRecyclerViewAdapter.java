package Gallery;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.webcamapplication.R;

import java.io.File;
import java.nio.file.Files;
import java.util.List;

public class MyItemRecyclerViewAdapter extends RecyclerView.Adapter<MyItemRecyclerViewAdapter.ViewHolder> {

    private final List<File> mFiles;
    private final GalleryPicturesFragment.OnListFragmentInteractionListener mListener;

    public MyItemRecyclerViewAdapter(List<File> mFiles, GalleryPicturesFragment.OnListFragmentInteractionListener mListener) {
        this.mFiles = mFiles;
        this.mListener = mListener;
    }


    @NonNull
    @Override
    public MyItemRecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
    }

    @Override
    public int getItemCount() {
        return 0;
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        private final View mItemView;
        private final ImageView mImageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.mItemView = itemView;
            mImageView = (ImageView) itemView.findViewById(R.id.imageView);

        }
    }
}
