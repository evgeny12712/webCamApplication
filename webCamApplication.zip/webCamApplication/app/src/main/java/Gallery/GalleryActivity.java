package Gallery;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import CameraAndSupport.CameraClass;
import MainWindow.MainActivity;
import com.example.webcamapplication.R;

public class GalleryActivity extends AppCompatActivity {
    private Button btnSavedVideos;
    private Button btnPictures;
    private Button btnHome;
    private Button btnVideos;
    private GalleryTemporaryFilesFragment temporaryFiles;
    private GallerySavedFilesFragment savedFiles;
    private GalleryPicturesFragment pictures;
    private Resources res;
    private Toolbar mToolbar;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter recyclerViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);

        res = getResources();

        temporaryFiles = new GalleryTemporaryFilesFragment();
        savedFiles = new GallerySavedFilesFragment();
        pictures = new GalleryPicturesFragment();

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.gridFLayoutFragment, temporaryFiles)
                .commit();



        btnHome = (Button)findViewById(R.id.btnHome);
        btnVideos = (Button)findViewById(R.id.btnVideos);
        btnSavedVideos = (Button) findViewById(R.id.btnSavedVideos);
        btnPictures = (Button) findViewById(R.id.btnPictures);



        btnHome = (Button)findViewById(R.id.btnHome);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext() , MainActivity.class);
                startActivity(intent);
            }
        });

        btnVideos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.gridFLayoutFragment, temporaryFiles)
                        .commit();
                setButtonPressed("videos");
            }
        });

        btnSavedVideos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(GalleryActivity.this, "savedVideos", Toast.LENGTH_SHORT).show();
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.gridFLayoutFragment, savedFiles)
                        .commit();
                setButtonPressed("savedVideos");
            }
        });

        btnPictures.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Toast.makeText(GalleryActivity.this, "Pictures", Toast.LENGTH_SHORT).show();
                Fragment currentFragment =  getSupportFragmentManager().findFragmentById(R.id.gallery_pictures_list);
                recyclerView = (RecyclerView) currentFragment.getView();
                recyclerViewAdapter = ((RecyclerView) currentFragment.getView()).getAdapter();
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.gridFLayoutFragment, pictures)
                        .commit();
                setButtonPressed("pictures");

            }
        });




//        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                Toast.makeText(GalleryActivity.this, "id" + position, Toast.LENGTH_SHORT).show();
//                Intent intent = new Intent(getApplicationContext(), FullScreenActivity.class);
//                intent.putExtra("id", position);
//                startActivity(intent);
//            }
//        });
    }

    @Override
    protected void onResume() {
        super.onResume();

//        runOnUiThread(new Runnable() {
//
//            @Override
//            public void run() {
//                FilesContent.loadSavedFiles(CameraClass.getmImageFolder());
////                recyclerViewAdapter.notifyDataSetChanged();
//            }
//        });
    }

    public void setButtonPressed(String buttonName) {
        int grey = res.getColor(R.color.grey);
        int darkGrey = res.getColor(R.color.darkGrey);
        switch (buttonName) {
            case "videos":
                btnVideos.setBackgroundColor(darkGrey);
                btnSavedVideos.setBackgroundColor(grey);
                btnPictures.setBackgroundColor(grey);
                break;
            case "savedVideos":
                btnVideos.setBackgroundColor(grey);
                btnSavedVideos.setBackgroundColor(darkGrey);
                btnPictures.setBackgroundColor(grey);
                break;
            case "pictures":
                btnVideos.setBackgroundColor(grey);
                btnSavedVideos.setBackgroundColor(grey);
                btnPictures.setBackgroundColor(darkGrey);
                break;
        }
    }
}
